const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const ad = document.getElementById("ad-overlay");
const finalScore = document.getElementById("final-score");
const highScoreList = document.getElementById("high-score-list");
const freezeDisplay = document.getElementById("freeze-count");
const scoreDisplay = document.getElementById("score-display");
const jumpBtn = document.getElementById("jump-btn");
const freezeBtn = document.getElementById("freeze-btn");
const pauseBtn = document.getElementById("pause-btn");

const donateBtn = document.getElementById("donate-btn");
const donateMenu = document.getElementById("donate-menu");

donateBtn.addEventListener("click",()=>{donateMenu.style.display="flex";});
function closeDonateMenu(){donateMenu.style.display="none";}

// Load images
const Bird = new Image(); Bird.src="assets/Bird.png";
const Pipe = new Image(); Pipe.src="assets/pipe.png";
const Background = new Image(); Background.src="assets/background.png";

// Game variables
let birdY=300, velocity=0, gravity=0.45;
let pipes=[{x:360,heightTop:200,heightBottom:350,scored:false}];
let alive=true, freezeCharges=3, freezing=false, score=0;

// Pause
let paused=false;

// Local leaderboard
let highScores = JSON.parse(localStorage.getItem("highScores"))||[];

// Quests
let quests = {
  daily: {flaps:0,coins:0,completed:false,lastUpdated:new Date().toDateString()},
  weekly:{highScore:0,freezeUsed:0,completed:false,weekStart:new Date().toISOString()},
  monthly:{totalGames:0,coins:0,completed:false,month:new Date().getMonth()+1}
};

// Flap/jump
function flap(){
    if(alive){
        if(freezing) velocity = -3; // small jump during freeze
        else velocity = -8;
        quests.daily.flaps++;
    }
}

// Freeze
function startFreeze(){
  if(alive && freezeCharges>0 && !freezing){
    freezing = true;
    freezeCharges--;
    freezeDisplay.innerText = "Freeze: "+freezeCharges;
    canvas.style.filter = "brightness(1.3)";
    
    setTimeout(()=>{
        freezing = false;
        canvas.style.filter = "brightness(1)";
    }, 1200);
  }
}

// Pause button
pauseBtn.addEventListener("click", ()=>{
    paused = !paused;
    if(paused){
        canvas.style.filter = "brightness(0.5)";
    } else {
        canvas.style.filter = "brightness(1)";
        loop();
    }
});

// Inputs
jumpBtn.addEventListener("touchstart", e => { e.preventDefault(); flap(); });
jumpBtn.addEventListener("mousedown", e => { e.preventDefault(); flap(); });

freezeBtn.addEventListener("touchstart", e => { e.preventDefault(); startFreeze(); });
freezeBtn.addEventListener("mousedown", e => { e.preventDefault(); startFreeze(); });

// Save score
function saveScore(s){
  highScores.push(s); 
  highScores.sort((a,b)=>b-a); 
  highScores=highScores.slice(0,5);
  localStorage.setItem("highScores",JSON.stringify(highScores));
}

// Update leaderboard UI
function updateHighScoresUI(){
  highScoreList.innerHTML="";
  highScores.forEach(score=>{
    const li=document.createElement("li");
    li.innerText=score;
    highScoreList.appendChild(li);
  });
  finalScore.innerText="Score: "+score;
}

// Game Over
function gameOver(){
  alive=false;
  saveScore(score);
  updateHighScoresUI();
  setTimeout(()=>{ad.style.display="flex";},300);
}

// Reset/Respawn
function resetGame(){
  birdY = 300;
  velocity = 0;
  pipes = [{x:360, heightTop:200, heightBottom:350,scored:false}];
  alive = true;
  freezeCharges = 3;
  freezing = false;
  score = 0;
  freezeDisplay.innerText = "Freeze: "+freezeCharges;
  scoreDisplay.innerText = "Score: "+score;
  ad.style.display = "none";
  paused = false;
  canvas.style.filter = "brightness(0.5)";

  let brightness = 0.5;
  const fadeIn = setInterval(() => {
    brightness += 0.05;
    canvas.style.filter = "brightness(" + brightness + ")";
    if(brightness >= 1){
      clearInterval(fadeIn);
      loop();
    }
  },50);
}

// Main game loop
function loop(){
  if(paused || !alive) return; // stop updating if paused or dead

  ctx.clearRect(0,0,360,640);

  // Background
  if(Background.complete) ctx.drawImage(Background,0,0,360,640); 
  else {ctx.fillStyle="#1a1a1a"; ctx.fillRect(0,0,360,640);}

  // Bird movement
  if(!freezing) velocity += gravity;
  birdY += velocity;

  // Keep bird inside bounds
  if(birdY < 0) birdY = 0;
  if(birdY > 610) birdY = 610;

  // Draw Bird
  if(Bird.complete) ctx.drawImage(Bird,50,birdY,30,30); 
  else {ctx.fillStyle="yellow"; ctx.fillRect(50,birdY,30,30);}

  // Pipes
  pipes.forEach(p=>{
    if(!freezing) p.x -= 1.5; // only freeze stops pipes

    if(Pipe.complete){
      ctx.drawImage(Pipe,p.x,0,50,p.heightTop);
      ctx.drawImage(Pipe,p.x,p.heightBottom,50,640-p.heightBottom);
    } else {ctx.fillStyle="green"; ctx.fillRect(p.x,0,50,p.heightTop); ctx.fillRect(p.x,p.heightBottom,50,640-p.heightBottom);}

    // Collision
    if(50<p.x+50 && 50+30>p.x && (birdY<p.heightTop || birdY+30>p.heightBottom)) gameOver();

    // Score: +1 per pipe passed
    if(!p.scored && p.x + 50 < 50){
        score += 1;
        p.scored = true;
        scoreDisplay.innerText = "Score: "+score;
    }
  });

  // Add new pipes
  if(pipes.length===0 || pipes[pipes.length-1].x<180){
    const gap = 150; 
    const topHeight = Math.random()*250+50;
    pipes.push({x:360,heightTop:topHeight,heightBottom:topHeight+gap,scored:false});
  }

  requestAnimationFrame(loop);
}

loop();
